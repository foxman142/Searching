﻿using System;
using System.Collections.Generic;

namespace SearchingBinary
{
    class Program
    {

        static void Main(string[] args)
        {
            List<string> Geek = new List<string>();

            Geek.Add("ABCD");
            Geek.Add("QRST");
            Geek.Add("XYZ");
            Geek.Add("IJKL");

            Console.WriteLine("The Original List is:");
            foreach (string g in Geek)
            {
                Console.WriteLine(g);
            }

            Console.WriteLine("\nInsert EFGH :");

            int index = Geek.BinarySearch("EFGH");

            if (index < 0)
            {
                Geek.Insert(~index, "EFGH");
            }

            Console.WriteLine();

            foreach (string g in Geek)
            {
                Console.WriteLine(g);
            }

        }
    }
}
